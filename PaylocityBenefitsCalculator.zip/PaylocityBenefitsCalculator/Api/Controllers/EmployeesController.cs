﻿using Api.Dtos.Dependent;
using Api.Dtos.Employee;
using Api.Mapping;
using Api.Models;
using Dal.Data;
using Dal.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Swashbuckle.AspNetCore.Annotations;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Api.Controllers;

[ApiController]
[Route("api/v1/[controller]")]
public class EmployeesController : ControllerBase
{
    private readonly MainDbContext _context;

    public EmployeesController(MainDbContext context)
    {
        _context = context;
    }

    [SwaggerOperation(Summary = "Get employee by id")]
    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var employee = await _context.Employees.Include(n => n.Dependents).FirstOrDefaultAsync(n => n.Id == id);

        if (employee == null)
            return NotFound();

        var result = employee.MapToEmplyeeDto();

        return Ok(new ApiResponse<GetEmployeeDto> { Data = result, Success = true });
    }

    [SwaggerOperation(Summary = "Get all employees")]
    [HttpGet("")]
    public async Task<ApiResponse<List<GetEmployeeDto>>> GetAll()
    {
        var employees = await _context.Employees.Include(_ => _.Dependents).ToListAsync();

        if (employees == null || employees.Count == 0)
            return new ApiResponse<List<GetEmployeeDto>> { Success = false };

        var results = employees.Select(n => n.MapToEmplyeeDto());

        return new ApiResponse<List<GetEmployeeDto>> { Data = results.ToList(), Success = true };
    }

    [SwaggerOperation(Summary = "Calculate and view paycheck for an employee")]
    [HttpGet("{id}/paycheck")]
    public async Task<IActionResult> GetEmployeePaycheck(int id)
    {
        decimal baseCost = 1000;
        decimal dependentCost = 600; 
        decimal additionalSalaryPercentage = 0.02M;
        decimal seniorDependentCost = 200;

        decimal benefitsCost = baseCost;

        var employee = await _context.Employees.Include(n => n.Dependents).FirstOrDefaultAsync(n => n.Id == id);

        if (employee == null)
            return NotFound();

        if(employee.Salary> 80000)
            benefitsCost += employee.Salary * additionalSalaryPercentage;

        foreach (var dependent in employee.Dependents)
        {
            int dependentAge = CalculateAge(dependent.DateOfBirth);
            benefitsCost += dependentAge > 50 ? seniorDependentCost : dependentCost;
        }

        decimal benefitsCostPerPaycheck = benefitsCost / 26;

        var paycheck = employee.MapToEmployeePaycheckDto(benefitsCostPerPaycheck);

        return Ok(paycheck);
    }

    private int CalculateAge(DateTime dateOfBirth)
    {
        DateTime currentDate = DateTime.Now;
        int age = currentDate.Year - dateOfBirth.Year;

        if (dateOfBirth.Date > currentDate.AddYears(-age))
            age--;
        
        return age;
    }
}
