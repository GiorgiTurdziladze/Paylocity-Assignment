﻿using Api.Dtos.Dependent;
using Api.Mapping;
using Api.Models;
using Dal.Data;
using Dal.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Swashbuckle.AspNetCore.Annotations;

namespace Api.Controllers;

[ApiController]
[Route("api/v1/[controller]")]
public class DependentsController : ControllerBase
{
    private readonly MainDbContext _context;

    public DependentsController(MainDbContext context)
    {
        _context = context;
    }

    [SwaggerOperation(Summary = "Get dependent by id")]
    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var dependent = _context.Dependents.FirstOrDefault(n => n.Id == id);

        if (dependent == null) 
            return NotFound(new ApiResponse<GetDependentDto> { Error = "Not Found", Success=false});

        var result = dependent.MapToDependentDto();

        return Ok(new ApiResponse<GetDependentDto> {Data = result, Success= true });
    }

    [SwaggerOperation(Summary = "Get all dependents")]
    [HttpGet]
    public async Task<ApiResponse<List<GetDependentDto>>> GetAll()
    {
        var dependents = await _context.Dependents.ToListAsync();

        if (dependents == null || dependents.Count == 0)
            return new ApiResponse<List<GetDependentDto>> { Success = false };

        var results = dependents.Select(n => n.MapToDependentDto());

        return new ApiResponse<List<GetDependentDto>> { Data = results.ToList(), Success = true };
    }
}
