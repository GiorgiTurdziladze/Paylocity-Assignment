﻿using Api.Dtos.Dependent;
using Api.Dtos.Employee;
using Dal.Model;
using System.Collections.ObjectModel;

namespace Api.Mapping
{
    public static class ContractMapping
    {
        public static GetEmployeeDto MapToEmplyeeDto(this Employee employee)
        {
            return new GetEmployeeDto
            {
                Id = employee.Id,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                DateOfBirth = employee.DateOfBirth,
                Salary = employee.Salary,
                Dependents = employee.Dependents.MapToCollection()
            };
        }

        public static GetDependentDto MapToDependentDto(this Dependent dependent)
        {
            return new GetDependentDto
            {
                Id = dependent.Id,
                FirstName = dependent.FirstName,
                LastName = dependent.LastName,
                DateOfBirth = dependent.DateOfBirth,
                Relationship = dependent.Relationship
            };
        }

        public static GetEmployeeDto MapToEmployeePaycheckDto(this Employee employee, decimal benefitsCostPerPaycheck)
        {
            return new GetEmployeeDto
            {
                Id = employee.Id,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                DateOfBirth= employee.DateOfBirth,
                Salary = employee.Salary / 26 - benefitsCostPerPaycheck,
                Dependents = employee.Dependents.MapToCollection()
            };
        }

        private static ICollection<GetDependentDto> MapToCollection(this ICollection<Dependent> dependents)
        {
            var collection = new Collection<GetDependentDto>();

            foreach (var i in dependents)
            {
                collection.Add(i.MapToDependentDto());
            }

            return collection; ;
        }


    }
}
